import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-screen',
  templateUrl: './custom-screen.component.html',
  styleUrls: ['./custom-screen.component.scss']
})
export class CustomScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
